

import CoreData
import Foundation


class CoreData {
    
    static let shared = CoreData()
    private init() {}
    
    var newsAllData : [Article] = []
    var savedData : [Article] = []
    
    private lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "NewsAricalModel")
        container.loadPersistentStores { storeDescription, error in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        }
        return container
    }()
    
    
    // MARK: - Core Data stack
    private lazy var managedObjectContext: NSManagedObjectContext = {
        return persistentContainer.viewContext
    }()
    
    // MARK: - Save Context
    private func saveContext() {
        let context = managedObjectContext
        do {
            try context.save()
        } catch {
            let nserror = error as NSError
            fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }
    }
    // MARK: - Fetch Data from Core Data
    
    
    func fetchLocallySroredDataFromCoreData(completion: @escaping ([Article]) -> Void) {
        let fetchRequest: NSFetchRequest<NewsAricalsEntity> = NewsAricalsEntity.fetchRequest()
        do {
            let results = try managedObjectContext.fetch(fetchRequest)
            
            let artical = results.map {
                Article(id : $0.id ?? "" , isSavedLocally: $0.isSavedLocally, author : nil , title: $0.title ?? "", description : nil ,  url: $0.webUrl  ?? "", urlToImage: $0.imageUrl ?? "", publishedAt: nil, content: $0.newsContent ?? "")
            }
            completion(artical)
            
        } catch {
            print("Could not fetch: \(error)")
            completion([])
        }
    }
    // MARK: - Save API response into Core Data
    func saveNewsToCoreData(newsItems: [Article]) {
        for artical in newsItems {
            let fetchRequest: NSFetchRequest<NewsAricalsEntity> = NewsAricalsEntity.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "title == %@", artical.title ?? "" )
            
            let existing = try? managedObjectContext.fetch(fetchRequest)
            if existing?.isEmpty == false { continue }  // Avoid duplicates
            let entity = NewsAricalsEntity(context: managedObjectContext)
            entity.id = artical.id
            entity.title = artical.title
            entity.newsContent = artical.content
            entity.webUrl = artical.url
            entity.imageUrl = artical.urlToImage
            entity.isSavedLocally = artical.isSavedLocally
        }
        saveContext()
    }
    
    // MARK: -Save an article to "Saved List"
    
    func toggleSave(artical: Article , isSave : Bool ){
        
        let fetchRequest: NSFetchRequest<NewsAricalsEntity> = NewsAricalsEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", artical.id )
        do {
            let results = try managedObjectContext.fetch(fetchRequest)
            if let entityToUpdate = results.first {
                //                entityToUpdate.id = artical.id
                //                entityToUpdate.title = artical.title
                //                entityToUpdate.newsContent = artical.content
                //                entityToUpdate.webUrl = artical.url
                //                entityToUpdate.imageUrl = artical.urlToImage
                entityToUpdate.isSavedLocally = isSave
                
                saveContext()
            }
        } catch {
            print("Error updating account: \(error)")
        }
    }
    
    // MARK: - Fetch saved articals
    func fetchSavedNews(completion: @escaping ([Article]) -> Void) {
        let request: NSFetchRequest<NewsAricalsEntity> = NewsAricalsEntity.fetchRequest()
        request.predicate = NSPredicate(format: "isSavedLocally == %@", NSNumber(value: true))
        do {
            let  savedNews = try managedObjectContext.fetch(request)
            let artical = savedNews.map {
                Article(id : $0.id ?? "" , isSavedLocally: $0.isSavedLocally, author : nil , title: $0.title ?? "", description : nil ,  url: $0.webUrl  ?? "", urlToImage: $0.imageUrl ?? "", publishedAt: nil, content: $0.newsContent ?? "")
            }
            completion( artical)
        } catch {
            print(" Failed to fetch saved news:", error.localizedDescription)
            completion([])
        }
    }
    
}

