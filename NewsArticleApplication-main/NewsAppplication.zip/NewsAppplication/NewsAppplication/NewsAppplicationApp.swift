//
//  NewsAppplicationApp.swift
//  NewsAppplication
//
//  Created by Geetha Sai Durga on 18/03/25.
//

import SwiftUI

@main
struct NewsAppplicationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
          
        }
    }
}
