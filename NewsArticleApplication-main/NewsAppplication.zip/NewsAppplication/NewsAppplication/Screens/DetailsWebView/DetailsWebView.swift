//
//  DetailsWebView.swift
//  NewsAppplication
//
//  Created by Geetha Sai Durga on 18/03/25.
//

import SwiftUI
import WebKit

struct DetailsWebView: View {
    // MARK: - Properties
    let urlString: String
    @ObservedObject var newsViewModel: NewsListViewModel
    var articalDetails: Article?
    @State private var navigateToSavedList: Bool = false
    @EnvironmentObject var tabViewModel: TabViewModel
    @State private var isSharing: Bool = false

    // MARK: - Body
    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottomTrailing) {
                WebView(urlString: urlString)

                // MARK: - Save Button
                if tabViewModel.selectedTab == 0 || articalDetails?.isSavedLocally == false {
                    Button {
                        print("Save clicked")
                        newsViewModel.toggleSaveNewsData(articalData: articalDetails)
                        tabViewModel.selectedTab = 1
                    } label: {
                        HStack(spacing: 5) {
                            Text("Save")
                                .font(.system(size: 15, weight: .bold))
                                .foregroundColor(.white)
                        }
                        .padding()
                        .background(Color.blue, in: Circle())
                        .shadow(radius: 5)
                    }
                    .padding(.trailing, 20)
                    .padding(.bottom, 20)
                }
            }
            // MARK: - Toolbar
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        isSharing = true
                    }) {
                        Image(systemName: "square.and.arrow.up")
                    }
                }
            }
            // MARK: - Share Sheet
            .sheet(isPresented: $isSharing) {
                if let validURL = URL(string: urlString) {
                    ShareSheet(activityItems: [validURL])
                } else {
                    Text("Invalid URL")
                        .font(.headline)
                        .padding()
                }
            }
            .toolbarColorScheme(.light, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbar(.hidden, for: .tabBar)
        }
    }
}

// MARK: - WebView for displaying web content
struct WebView: UIViewRepresentable {
    let urlString: String
    
    func makeUIView(context: Context) -> WKWebView {
        return WKWebView()
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {
        if let url = URL(string: urlString) {
            let request = URLRequest(url: url)
            webView.load(request)
        }
    }
}
