//
//  NewsListViewModel.swift
//  NewsAppplication
//
//  Created by hb on 18/03/25.
//

import Foundation
import Alamofire

class TabViewModel: ObservableObject {
    @Published var selectedTab: Int = 0
}

class NewsListViewModel : ObservableObject{
    @Published var newsListDataSource = [Article]()
    @Published var savedNewsListDataSource = [Article]()
    var calledApi = false
    func callNewsAricalListApi(_ loadMoreData: Bool? = true){
        CoreData.shared.fetchLocallySroredDataFromCoreData(completion: { articalData in
            self.newsListDataSource = articalData
        })
        ApiHandler.getApiData(url: AppUrls.getNewsListUrl, method: .get) { (data, error) in
            self.calledApi = true
            if let data = data{
                do{
                    if let resposeData = try? JSONDecoder().decode(NewsListModel.self, from: data){
                        if let aritcalsData =  resposeData.articles {
                            CoreData.shared.saveNewsToCoreData(newsItems: aritcalsData)
                            CoreData.shared.fetchLocallySroredDataFromCoreData(completion: { articalData in
                                self.newsListDataSource = articalData
                            })
                        }
                    }
                } 
            } else {
                print("Error")
                ToastMessages.shared.toastMessage(error?.localizedDescription ?? "error")
            }
        }
    }
    
    
    func toggleSaveNewsData(articalData : Article? , isSave : Bool = true) {
        if let articalData = articalData {
            CoreData.shared.toggleSave(artical: articalData , isSave: isSave)
            fetchAllSavedData()
            CoreData.shared.fetchLocallySroredDataFromCoreData(completion: { articalData in
                self.newsListDataSource = articalData
            })
        }
    }
    
    func fetchAllSavedData() {
        CoreData.shared.fetchSavedNews() { data in
            self.savedNewsListDataSource = data
        }
    }
}
