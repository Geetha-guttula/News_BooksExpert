//
//  NewsListView.swift
//  NewsAppplication
//
//  Created by Geetha Sai Durga on 18/03/25.
//

import SwiftUI

struct NewsListView: View {
    // MARK: - Properties
    @State var newsList: [Article] = []
    @StateObject var newsViewModel = NewsListViewModel()
    @State var selectedNews: Article?
    @State var isReadMoreDetailsClicked: Bool = false
    
    // MARK: - Init Method
    init() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor(red: 89 / 255, green: 13 / 255, blue: 228 / 255, alpha: 1)
        appearance.titleTextAttributes = [
            .foregroundColor: UIColor.white,
            .font: UIFont.boldSystemFont(ofSize: 22)
        ]
        UINavigationBar.appearance().standardAppearance = appearance
        UINavigationBar.appearance().scrollEdgeAppearance = appearance
    }
    
    // MARK: - Body
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 10) {
                if newsList.isEmpty {
                    NodataView()
                } else {
                    List {
                        ForEach(newsList) { article in
                            NewslistItem(isShowMoreDetails: $isReadMoreDetailsClicked, selectedNews: $selectedNews, articalDetails: article, newsViewModel: newsViewModel)
                                .listRowSeparator(.hidden)
                                .padding(.vertical, 5)
                        }
                    }
                    .listStyle(.plain)
                    .navigationDestination(isPresented: $isReadMoreDetailsClicked) {
                        if let selectedNews = selectedNews {
                            DetailsWebView(
                                urlString: selectedNews.url ?? "",
                                newsViewModel: newsViewModel,
                                articalDetails: selectedNews
                            )
                        }
                    }
                    .refreshable {
                        newsViewModel.callNewsAricalListApi()
                    }
                }
            }
            .padding()
            .navigationTitle("News Articles")
            .navigationBarTitleDisplayMode(.inline)
        }
        .onAppear {
            newsViewModel.callNewsAricalListApi()
        }
        .onReceive(newsViewModel.$newsListDataSource) { data in
            newsList = data
        }
        .toolbarColorScheme(.light, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
    }
}

#Preview {
    NewsListView()
}

// MARK: - News List Item
struct NewslistItem: View {
    @Binding var isShowMoreDetails: Bool
    @Binding var selectedNews: Article?
    
    var articalDetails: Article
    var itemType: NewsItemType = .NewsList
    @ObservedObject var newsViewModel: NewsListViewModel
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(articalDetails.title ?? "")
                    .font(.system(size: 20, weight: .bold))
                
                if itemType == .SvedNewsList {
                    Button {
                        newsViewModel.toggleSaveNewsData(articalData: articalDetails, isSave: false)
                    } label: {
                        Image(systemName: "trash.fill")
                            .foregroundColor(.accentColor)
                    }
                    .buttonStyle(.plain)
                }
            }
            
            HStack(spacing: 10) {
                VStack {
                    if let url = URL(string: articalDetails.urlToImage ?? ""), !articalDetails.urlToImage!.isEmpty {
                        AsyncImage(url: url) { phase in
                            switch phase {
                            case .empty:
                                ProgressView()
                                    .frame(maxWidth: 100, maxHeight: 100)
                            case .success(let image):
                                ZStack(alignment: .bottomLeading) {
                                    image
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .frame(maxWidth: 100, maxHeight: 150)
                                        .blur(radius: 10)
                                        .clipped()
                                        .clipShape(RoundedCornerShape(corners: [.allCorners], radius: 10))
                                    image
                                        .resizable()
                                        .scaledToFit()
                                        .frame(maxWidth: 100, maxHeight: 150)
                                        .clipped()
                                        .clipShape(RoundedCornerShape(corners: [.allCorners], radius: 10))
                                }
                            case .failure(_):
                                EmptyView()
                            @unknown default:
                                EmptyView()
                            }
                        }
                    }
                }
                
                VStack(spacing: 5) {
                    Text(articalDetails.content ?? "")
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(.primary)
                        .padding(.bottom, 5)
                    
                    HStack {
                        Spacer()
                        Button {
                            if Connectivity.isConnectedToInternet() {
                                selectedNews = articalDetails
                                isShowMoreDetails = true
                            } else {
                                ToastMessages.shared.toastMessage("Please check Internet Connectivity")
                            }
                        } label: {
                            Text("Read More...")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundColor(.accentColor)
                        }
                        .tint(.accentColor)
                        .buttonStyle(.plain)
                    }
                }
            }
        }
        .contentShape(Rectangle())
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(Color(uiColor: .systemBackground))
                .shadow(color: .gray.opacity(0.3), radius: 5, x: 0, y: 2)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color.primary, lineWidth: 1)
        )
    }
}

// MARK: - Custom Rounded Corner Shape
struct RoundedCornerShape: Shape {
    var corners: UIRectCorner
    var radius: CGFloat
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        )
        return Path(path.cgPath)
    }
}

// MARK: - No Data View
struct NodataView: View {
    var body: some View {
        VStack {
            Spacer()
            Text("No News data found.")
                .multilineTextAlignment(.center)
                .font(.system(size: 14, weight: .bold))
                .padding()
            Spacer()
        }
    }
}
