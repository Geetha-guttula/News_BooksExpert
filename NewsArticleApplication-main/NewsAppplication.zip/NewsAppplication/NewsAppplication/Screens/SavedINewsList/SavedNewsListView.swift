//
//  SavedNewsListView.swift
//  NewsAppplication
//
//  Created by Geetha Sai Durga on 18/03/25.
//

import SwiftUI

struct SavedNewsListView: View {
    
    @State var newsList : [Article] = []
    @StateObject var newsViewModel = NewsListViewModel()
    @State var selectedNews : Article?
   
    @State var isReadMoreDetailsClicked : Bool = false
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading) {
                if newsList.isEmpty {
                    NodataView()
                } else {
                    List {
                        ForEach(newsList ) { artical in
                            NewslistItem(isShowMoreDetails: $isReadMoreDetailsClicked, selectedNews: $selectedNews, articalDetails: artical , itemType : .SvedNewsList , newsViewModel: newsViewModel)
                                .listRowSeparator(.hidden)
                        }
                    }
                    .listStyle(.plain)
                    .navigationDestination(isPresented: $isReadMoreDetailsClicked) {
                        if let selectedNews = selectedNews {
                            DetailsWebView(
                                urlString: selectedNews.url ?? "",
                                newsViewModel: newsViewModel,
                                articalDetails: selectedNews
                            )
                        }
                    }
                    .refreshable {
                        newsViewModel.fetchAllSavedData()
                    }
                }
            }
            .padding()
            .navigationTitle("Saved Articles")
            .navigationBarTitleDisplayMode(.inline)
            }
        
        .onAppear {
            newsViewModel.fetchAllSavedData()
        }
        .onReceive( newsViewModel.$savedNewsListDataSource ) { data in
            newsList = data
        }
        .toolbarColorScheme(.light, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
    }
}

#Preview {
    SavedNewsListView()
}
