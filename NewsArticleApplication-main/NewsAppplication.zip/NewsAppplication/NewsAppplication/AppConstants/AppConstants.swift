//
//  AppConstants.swift
//  taskNUSHIFT
//
//  Created by Kishore on 14/02/23.

import Foundation

struct AppUrls{
    static let getNewsListUrl = "https://newsapi.org/v2/everything?domains=wsj.com&apiKey=dd4ed2bb2b5d4c2391e8ec06097a6d92"
}
