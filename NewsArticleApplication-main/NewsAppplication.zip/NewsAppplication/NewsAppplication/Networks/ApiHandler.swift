//
//  ContentView.swift
//  NewsAppplication
//
//  Created by Geetha Sai Durga on 18/03/25.
//

import Foundation
import Alamofire

enum Methods {
    case get,post
}

class ApiHandler {
    
    static func getApiData(url: String, method: Methods, completion:@escaping (_ data: Data?,_ error: Error?)->Void){
        if Connectivity.isConnectedToInternet() {
            print("Internet is available.")
            switch method{
            case .get:
                print("Get")
                AF.request(url, method: .get).response{ response in
                    if let data = response.data,let value = response.value{
                        completion(data,nil)
                    }else{
                        print("Error")
                        completion(nil,response.error)
                    }
                }
            case .post:
                print("Post")
                AF.request(url, method: .post, encoding: JSONEncoding.default).response{ response in
                    if let data = response.data,let value = response.value{
                        print(value as Any)
                        completion(data,nil)
                    }else{
                        print("Error")
                        completion(nil,response.error)
                    }
                }
            }
        }else{
            ToastMessages.shared.toastMessage(" Please check InternetConnectivity ")
        }
    }
}

class Connectivity {
    class func isConnectedToInternet() ->Bool {
        return NetworkReachabilityManager()!.isReachable
    }
}

