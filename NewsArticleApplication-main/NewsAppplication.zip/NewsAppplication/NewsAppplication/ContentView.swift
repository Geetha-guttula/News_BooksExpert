//
//  ContentView.swift
//  NewsAppplication
//
//  Created by Geetha Sai Durga on 18/03/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject var tabViewModel = TabViewModel()
    var body: some View {
        TabView(selection: $tabViewModel.selectedTab) {
            NewsListView()
                .tabItem {
                    Label("Home", systemImage: "house.circle.fill")
                }
                .tag(0)
            
            SavedNewsListView()
                .tabItem {
                    Label("Saved", systemImage: "arrowshape.down.circle.fill")
                }
                .tag(1)
        }
        .environmentObject(tabViewModel)
    }
    
}

#Preview {
    ContentView()
}
